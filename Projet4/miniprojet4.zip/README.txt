Instruction pour faire fonctionner les projet:

1) Extraire tout le dossier zip
2) entrez la commande "python3 miniprojet4"
3) profitez de l'aventure

Si vous avez des question vis-à-vis de l'utilisation du programme envoyez un mail à cette adresse: gtionogu@ulb.ac.be
